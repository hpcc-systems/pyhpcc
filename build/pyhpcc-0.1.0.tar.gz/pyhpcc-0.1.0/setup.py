# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pyhpcc']

package_data = \
{'': ['*']}

install_requires = \
['elementpath>=3.0.2,<4.0.0',
 'pandas>=2.2.0,<3.0.0',
 'requests>=2.32.3,<3.0.0',
 'requests_oauthlib>=1.3.1,<2.0.0',
 'six>=1.16.0,<2.0.0',
 'sphinx-rtd-theme>=1.0.0,<2.0.0',
 'sphinx>=5.2.3,<6.0.0']

setup_kwargs = {
    'name': 'pyhpcc',
    'version': '0.1.0',
    'description': 'Pyhpcc is a python package that allows accessing hpcc-systems via python.',
    'long_description': '# PyHPCC\n\nPyhpcc is a Python package that allows accessing HPCC-systems via Python.\n\nPyHPCC is a Python package and wrapper built around the [HPCC Systems](https://hpccsystems.com/) web services that facilitate communication between Python and HPCC Systems. \n# Features\nSome core functionalities PyHPCC supports are\n1. Work Unit submission through inline queries or using a Git Repository.\n2. Reading contents from a Logical file.\n3. Uploading files to a landing zone\n4. Making Roxie calls.\n## ⚙️ Installation\n\n### Prerequisites\n\nTo use PyHPCC, you need these<br>\n1. [Python3](https://www.python.org/downloads/)\n2. [ECL Client Tools](https://hpccsystems.com/download/): Select your operating systems to download client tools\n\nDownload the latest stable build from releases in GitHub.<br>\n\n``` bash\npip install pyhpcc-<version>.tar.gz\n#or\npip install pyhpcc-<version>-py3-none-any.whl\n```\n\n## 🚀 Quick Start\nSee the following [example](examples/work_unit_hello_world.py) to OUTPUT `Hello World` with ECL.\n\nFor more examples, check the [examples](examples) folder.\n\n\n## For Contributors\nContributions to PyHPCC are welcomed and encouraged.<br>\nFor specific contribution guidelines, please take a look at [CONTRIBUTING.md](CONTRIBUTING.md).\n\n\nFor more information about the package, please refer to the detailed documentation - https://upgraded-bassoon-daa9d010.pages.github.io/build/html/index.html\n\n',
    'author': 'Amila De silva',
    'author_email': 'Amila.De@lexisnexisrisk.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.12,<4.0',
}


setup(**setup_kwargs)
